# SSM整合

#### 整合的步骤

- 1 首先搭建开发环境，进行分层，controller,service,dao
- 2 创建spring的开发环境
- 3 创建springmvc开发环境
- 4 整合spirng和springmvc开发环境
- 5 创建mybatis开发环境
- 6 整合spring和mybatis的开发环境

回顾开发环境的作用：

- spring：spring是一个容器，所有的框架的对象都必须交给spring容器进行管理

标识webapp

- ![1559956439763](ssm.assets/1559956439763.png)

![1559956496871](ssm.assets/1559956496871.png)

![1559956513307](ssm.assets/1559956513307.png)

![1559956572815](ssm.assets/1559956572815.png)

#### 搭建spring开发环境

##### 1 添加pom文件里面的坐标：

~~~
 <packaging>war</packaging>

    <properties>
        <spring.version>5.0.2.RELEASE</spring.version>
        <slf4j.version>1.6.6</slf4j.version>
        <log4j.version>1.2.12</log4j.version>
        <mysql.version>5.1.6</mysql.version>
        <mybatis.version>3.4.5</mybatis.version>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
    </properties>


    <dependencies>

        <!-- spring -->
        <dependency>
            <groupId>org.aspectj</groupId>
            <artifactId>aspectjweaver</artifactId>
            <version>1.6.8</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-aop</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-context</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-web</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-webmvc</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-test</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-tx</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-jdbc</artifactId>
            <version>${spring.version}</version>
        </dependency>

        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
            <scope>compile</scope>
        </dependency>

        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>${mysql.version}</version>
        </dependency>

        <dependency>
            <groupId>javax.servlet</groupId>
            <artifactId>servlet-api</artifactId>
            <version>2.5</version>
            <scope>provided</scope>
        </dependency>

        <dependency>
            <groupId>javax.servlet.jsp</groupId>
            <artifactId>jsp-api</artifactId>
            <version>2.0</version>
            <scope>provided</scope>
        </dependency>

        <dependency>
            <groupId>jstl</groupId>
            <artifactId>jstl</artifactId>
            <version>1.2</version>
        </dependency>

        <!-- log start -->
        <dependency>
            <groupId>log4j</groupId>
            <artifactId>log4j</artifactId>
            <version>${log4j.version}</version>
        </dependency>

        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-api</artifactId>
            <version>${slf4j.version}</version>
        </dependency>

        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-log4j12</artifactId>
            <version>${slf4j.version}</version>
        </dependency>
        <!-- log end -->
        <dependency>
            <groupId>org.mybatis</groupId>
            <artifactId>mybatis</artifactId>
            <version>${mybatis.version}</version>
        </dependency>

        <dependency>
            <groupId>org.mybatis</groupId>
            <artifactId>mybatis-spring</artifactId>
            <version>1.3.0</version>
        </dependency>

        <dependency>
            <groupId>c3p0</groupId>
            <artifactId>c3p0</artifactId>
            <version>0.9.1.2</version>
            <type>jar</type>
            <scope>compile</scope>
        </dependency>

    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.tomcat.maven</groupId>
                <artifactId>tomcat7-maven-plugin</artifactId>
                <version>2.2</version>
                <configuration>
                    <port>18081</port>
                    <path>/</path>
                </configuration>
            </plugin>
        </plugins>
    </build>
~~~

##### 2 创建数据库

~~~
 create database ssm;
  use ssm;
  create table account(
    id int primary key auto_increment,
    name varchar(20),
    money double
  );
~~~

##### 3 创建javabean

~~~java
package com.itheima.domain;

import java.io.Serializable;

/**
 * Account
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public class Account implements Serializable {
    private Integer id;
    private String name;
    private double money;
~~~

##### 4 创建DAO

~~~java
package com.itheima.dao;

import com.itheima.domain.Account;

import java.util.List;

/**
 * AccountDao
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public interface AccountDao {

    /**
     * 查询所有的账户
     * @return
     */
    public List<Account> findAll();

    /**
     * 保存账户
     * @param account
     * @return
     */
    public int add(Account account);


}
~~~

##### 5 创建service

~~~java
package com.itheima.service;

import com.itheima.domain.Account;

import java.util.List;

/**
 * AccountService
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public interface AccountService {

    public List<Account> findAll();

    public void add(Account account);

}



package com.itheima.service.impl;

import com.itheima.domain.Account;
import com.itheima.service.AccountService;

import java.util.List;

/**
 * AccountServiceImpl
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
@Service
public class AccountServiceImpl implements AccountService {
    public List<Account> findAll() {
        System.out.println("AccountServiceImpl----findAll");
        return null;
    }

    public void add(Account account) {
        System.out.println("AccountServiceImpl---add");
    }
}
~~~

##### 6 创建controller

~~~java
package com.itheima.controller;

import com.itheima.domain.Account;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * AccountController
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
@Controller
@RequestMapping("/account")
public class AccountController {
    
    @RequestMapping("/findAll")
    public String findAll(){
        System.out.println("AccountController-----findAll");
        return "success";
    }
    
    @RequestMapping("/add")
    public String add(Account account){
        System.out.println("AccountController---add");
        return "redirect:/account/findAll";
    }
}
~~~

#### 创建spring的开发环境

##### 1 在资源文件下面创建一个叫做spring.xml文件

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:aop="http://www.springframework.org/schema/aop"
       xmlns:tx="http://www.springframework.org/schema/tx"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
    http://www.springframework.org/schema/beans/spring-beans.xsd
    http://www.springframework.org/schema/context
    http://www.springframework.org/schema/context/spring-context.xsd
    http://www.springframework.org/schema/aop
    http://www.springframework.org/schema/aop/spring-aop.xsd
    http://www.springframework.org/schema/tx
    http://www.springframework.org/schema/tx/spring-tx.xsd">

    <context:component-scan base-package="com"></context:component-scan>
</beans>
~~~

##### 2 测试spring的开发环境

~~~java
package com.itheima.service;

import com.itheima.domain.Account;
import com.itheima.service.impl.AccountServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * MyService
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public class MyService {


    private AccountService service;

    @Before
    public void testService(){
        ApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring.xml");
        service = context.getBean(AccountServiceImpl.class);
    }

    @Test
    public void testFindAll(){
        List<Account> lists = service.findAll();
    }
}
~~~

#### 创建springmvc的配置环境

##### 1 需要在web-inf文件夹下面配置web.xml文件

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
         version="4.0">
    

    <!--配置前端控制器-->
    <servlet>
        <servlet-name>dispatcherServlet</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>classpath:springmvc.xml</param-value>
        </init-param>
        <load-on-startup>1</load-on-startup>
    </servlet>
    <servlet-mapping>
        <servlet-name>dispatcherServlet</servlet-name>
        <url-pattern>/</url-pattern>
    </servlet-mapping>

    <!--配置字符编码乱码的过滤器-->
    <filter>
        <filter-name>characterEncodingFilter</filter-name>
        <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
        <init-param>
            <param-name>encoding</param-name>
            <param-value>UTF-8</param-value>
        </init-param>
    </filter>
    <filter-mapping>
        <filter-name>characterEncodingFilter</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>
    
</web-app>
~~~

##### 2 配置springmvc.xml

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:mvc="http://www.springframework.org/schema/mvc" xmlns:context="http://www.springframework.org/schema/context"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="
       http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/mvc
       http://www.springframework.org/schema/mvc/spring-mvc.xsd
       http://www.springframework.org/schema/context
       http://www.springframework.org/schema/context/spring-context.xsd">


    <context:component-scan base-package="com"></context:component-scan>


    <!--配置视图解析器-->
    <bean id="viewResolver" class="org.springframework.web.servlet.view.InternalResourceViewResolver">
        <property name="prefix" value="/WEB-INF/pages/"></property>
        <property name="suffix" value=".jsp"></property>
    </bean>

    <!--给js，css，image文件夹进行放行-->
    <mvc:resources mapping="/js/**" location="/js/"></mvc:resources>
    <mvc:resources mapping="/css/**" location="/css/"></mvc:resources>
    <mvc:resources mapping="/image/**" location="/image/"></mvc:resources>


    <mvc:annotation-driven></mvc:annotation-driven>
</beans>
~~~

##### 3 测试mvc的环境

- 1 需要在webapp下面新建index.jsp页面

- ```
  <a href="/account/findAll">测试查询所有</a><br/>
  <a href="/account/add">测试添加</a><br/>
  ```

- 2 在web-inf文件夹下面创建pages，然后新建success.jsp

##### 4 启动maven插件进行测试

![1559960107365](ssm.assets/1559960107365.png)

![1559960144355](ssm.assets/1559960144355.png)

##### 5 整合spring和springmvc

需要在springmvc的配置文件里面导入spirng.xml的文件

```
<!--导入spring.xml文件-->
<import resource="classpath:spring.xml"></import>
```

==需要注意：一定要把spring.xml里面的扫包的操作注释掉==

如果不注释spring.xml里面的配置文件，会造成冲突，事务不起作用

#### 创建mybatis的开发环境

##### 1 资源文件下面创建SqlMapconfig的文件

~~~xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE configuration
        PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>

    <!--添加mysql的开发环境-->
    <environments default="mysql">
        <environment id="mysql">
            <transactionManager type="JDBC"/>
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.jdbc.Driver"/>
                <property name="url" value="jdbc:mysql://127.0.0.1:3306/springmvc"/>
                <property name="username" value="root"/>
                <property name="password" value="root"/>
            </dataSource>
        </environment>
    </environments>

    <!--添加dao的映射文件-->

    <mappers>
        <package name="com.itheima.dao"></package>
    </mappers>


</configuration>
~~~

##### 2 在dao文件上面添加注解

~~~~java
package com.itheima.dao;

import com.itheima.domain.Account;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * AccountDao
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public interface AccountDao {

    /**
     * 查询所有的账户
     * @return
     */
    @Select("select * from account")
    public List<Account> findAll();

    /**
     * 保存账户
     * @param account
     * @return
     */
    @Insert("insert into account(name,money) values(#{name},#{money})")
    public int add(Account account);


}
~~~~

##### 3 测试

~~~java
package com.itheima.dao;

import com.itheima.domain.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import org.mybatis.spring.SqlSessionFactoryBean;

import java.io.InputStream;
import java.util.List;

/**
 * MyBatis
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
public class MyBatis {


    @Test
    public void testFindAll() throws Exception{
        InputStream is = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSession sqlSession = new SqlSessionFactoryBuilder().build(is).openSession();
        AccountDao dao = sqlSession.getMapper(AccountDao.class);
        Account account = new Account();
        account.setName("哈哈");
        account.setMoney(100d);
        dao.add(account);
        sqlSession.commit();
//        List<Account> lists = dao.findAll();
//        for (Account list : lists) {
//            System.out.println(list);
//        }
    }

}
~~~

#### spring整合mybatis

##### 1 在spirng.xml文件里面添加

~~~xml
<!--因为把spring.xml已经包含到了springmvc.xml文件，在springmvc.xml文件里面已经有了扫描包的操作，所以需要注释-->
    <!--<context:component-scan base-package="com"></context:component-scan>-->

    <bean id="dataSource" class="org.springframework.jdbc.datasource.DriverManagerDataSource">
        <property name="driverClassName" value="com.mysql.jdbc.Driver"/>
        <property name="url" value="jdbc:mysql://127.0.0.1:3306/springmvc"/>
        <property name="username" value="root"/>
        <property name="password" value="root"/>
    </bean>

    <bean id="sessionFactory" class="org.mybatis.spring.SqlSessionFactoryBean">
        <property name="dataSource" ref="dataSource"></property>
    </bean>

    <!-- 配置扫描dao的包 -->
    <bean id="mapperScanner" class="org.mybatis.spring.mapper.MapperScannerConfigurer">
        <property name="basePackage" value="com.itheima.dao"/>
    </bean>

    <!-- 配置事务管理器 -->
    <bean id="transactionManager" class="org.springframework.jdbc.datasource.DataSourceTransactionManager">
        <property name="dataSource" ref="dataSource"/>
    </bean>

    <!-- 配置事务通知 -->
    <tx:advice id="txAdvice" transaction-manager="transactionManager">
        <tx:attributes>
            <tx:method name="find*" read-only="true"/>
            <tx:method name="*" isolation="DEFAULT"/>
        </tx:attributes>
    </tx:advice>

    <!-- 配置AOP增强事务 -->
    <aop:config>
        <aop:advisor advice-ref="txAdvice" pointcut="execution(public * com.itheima.service.impl.*.*(..))"/>
    </aop:config>
~~~

##### 2 在index.jsp页面添加一个表单

~~~html
<%--
  Created by IntelliJ IDEA.
  User: ASUS
  Date: 2019/6/8
  Time: 10:12
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<a href="/account/findAll">测试查询所有</a><br/>
<a href="/account/add">测试添加</a><br/>

<form action="/account/add" method="post">
    姓名：<input type="text" name="name"/><br/>
    金额：<input type="text" name="money"/><br/>
    <input type="submit" value="保存"/><br/>
</form>
</body>
</html>

~~~

##### 3 在serive里面调用到

~~~java
package com.itheima.service.impl;

import com.itheima.dao.AccountDao;
import com.itheima.domain.Account;
import com.itheima.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * AccountServiceImpl
 *
 * @Author: 马伟奇
 * @CreateTime: 2019-06-08
 * @Description:
 */
@Service
public class AccountServiceImpl implements AccountService {


    @Autowired
    private AccountDao accountDao;

    public List<Account> findAll() {
        System.out.println("AccountServiceImpl----findAll");

        return  accountDao.findAll();
    }

    public void add(Account account) {
        System.out.println("AccountServiceImpl---add");
        accountDao.add(account);
        int a = 1/0;
    }
}
~~~

